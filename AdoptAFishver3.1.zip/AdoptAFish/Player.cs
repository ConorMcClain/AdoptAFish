﻿using AdoptAFish;

namespace AdoptAFish
{
    public class Player
    {
        //attributes - C# fields or properties
        public string Name = "Anonymous Player";
        public Tank tank = new Tank();
        public Tank[] tanks = new Tank[4];

        //operations - C# methods

        public Player(string name)
        {
            Name = name;
            SetUpTanks();

        }
        public Player()
        {
            SetUpTanks();
        }
        private void SetUpTanks()
        {
            for (int i = 0; i < tanks.Length; i++)
            {
                tanks[i] = new Tank() { tankName = $"tank #{i + 1}" };
            }

            tanks[tanks.Length - 1].Fishes.Remove(tanks[tanks.Length - 1].Fishes[tanks[tanks.Length - 1].Fishes.Count - 1]);
        }
        public string Information()
        {
            string output = "";
            //output += $"{Name}, you have one tank. Inside the tank is a {tanks[0].Fishes[0].FishColor} colored fish named {tanks[0].Fishes[0].FishName}";
            foreach (Tank tank in tanks)
            {
                output += $"{tank.tankName}\n{tank.Information()}";
            }
            return output;
        }
    }
}
